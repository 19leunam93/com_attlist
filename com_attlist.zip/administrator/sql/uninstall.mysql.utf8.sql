DROP TABLE IF EXISTS `#__attlist_item`;
